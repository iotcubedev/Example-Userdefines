package innerproject;

public class CustomClass {
	public int run() {
		
		System.out.println("This message is from CustomClass of innerproject");
		
		
		return 0;
	}
}
